//WATCH EPISODE 7 FOR EXPLAINATION

client.config = require('./config.json')