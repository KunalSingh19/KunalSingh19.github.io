# [Instagram Photo Downloader](https://kunalsingh19.github.io/Insta-Photo-Downloader/) :fire:

Free, Clean & Simple **Instagram Photo Downloader** for you. :slightly_smiling_face: <br>
Download **Instagram Photos** in high quality with ease.<br>

---

#### Libraries Used

---

* Bootstrap - http://getbootstrap.com/
* jQuery - http://jquery.com/

![Instagram Photo Downloader](https://img.shields.io/badge/Instagram-Photo%20Downloader-purple.svg)
