# [Simple Javascript Calculator](https://KunalSingh19.github.io/Java-Calculator) 

A simple JavaScript Calculator made by [KunalSingh19](https://KunalSingh19.github.io)

![Simple Javascript Calculator](https://raw.githubusercontent.com/KunalSingh19/Java-Calculator/master/meta.jpg)
